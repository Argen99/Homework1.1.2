package com.company2;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        System.out.println("Введите ваше имя");
        Scanner num = new Scanner(System.in);
        System.out.println(" Привет " + num.nextLine ());

	// write your code here
    }
}
